﻿using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using HtmlAgilityPack;

namespace Bounty.Dialogs
{

    public class AskingForAge : IDialog<object>
    {



        public async Task StartAsync(IDialogContext context)
        {

            string message = $"what is the age of the person??";

            await context.PostAsync(message);



        }

    }
}