﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Runtime.Remoting.Contexts;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using HtmlAgilityPack;


namespace Bounty.Dialogs
{
    public class WifeDialog : IDialog<object>

    {
        int i;
        Random r = new Random();



        public async Task StartAsync(IDialogContext context)
        {

            var message3 = context.MakeMessage();
            message3.Attachments = new List<Attachment>();
            message3.AttachmentLayout = "carousel";
            HtmlWeb web2 = new HtmlWeb();
            HtmlDocument doc2 = web2.Load("https://www.gifts.com/categories/for-your-wife/personalized-gifts/pxW1vV?navContent=T%3aWomen%3a%26nbsp%3b%26nbsp%3bWife&navLocation=T%3a4-9%3a7-9&tile=catpg_hero1&productgroup=glpfwif");
            var aTags = doc2.DocumentNode.SelectNodes("//img");

            if (aTags != null)
            {
                int count = 0;
                var a = "";
                foreach (var aTag in aTags)
                {

                    var msg = "";
                    var txt = "";
                    var href = "";

                    i = r.Next(1, 7);
                    if (i == 1)
                    {
                        a = "https://cimages.prvd.com/is/image/ProvideCommerce/PCR16";
                    }
                    if (i == 2)
                        a = "https://cimages.prvd.com/is/image/ProvideCommerce/RED15";
                    if (i == 3)
                        a = "https://cimages.prvd.com/is/image/ProvideCommerce/PCR17";
                    if (i == 4)
                        a = "https://cimages.prvd.com/is/image/ProvideCommerce/RED16";
                    if (i == 5)
                        a = "https://cimages.prvd.com/is/image/ProvideCommerce/PCR15";
                    if (i == 6)
                        a = "https://cimages.prvd.com/is/image/ProvideCommerce/RED";
                    if (i == 7)
                        a = "https://cimages.prvd.com/is/image/ProvideCommerce/PCR";
                    
                    if ((aTag.Attributes["src"].Value.StartsWith(a)) && count < 10)
                    {
                        //    msg = aTag.InnerHtml + " - " + aTag.Attributes["src"].Value + "\t" + "<br />";
                        msg = aTag.Attributes["src"].Value;
                        txt = aTag.Attributes["alt"].Value;
                        HtmlNode parentNode = aTag.ParentNode;
                        href = parentNode.Attributes["href"].Value;
                        List<CardImage> CardImages = new List<CardImage>();
                        CardImages.Add(new CardImage()
                        {
                            Url = msg.ToString()
                        });
                        var herocard3 = new HeroCard
                        {

                            Images = CardImages,
                            Title = txt,
                            Buttons = new List<CardAction> { new CardAction(ActionTypes.OpenUrl, "Click Here", value: href.ToString()) }
                        };

                        Attachment attachment1 = herocard3.ToAttachment();

                        message3.Attachments.Add(attachment1);
                        count = count + 1;
                    }
                }
                await context.PostAsync(message3);
                //context.Wait(this.MessageReceived);
                //context.Done(new Object());
            }
        }
    }
}