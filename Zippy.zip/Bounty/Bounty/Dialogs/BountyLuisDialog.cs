﻿//#define useSampleModel

using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using Microsoft.Bot.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using HtmlAgilityPack;

namespace Bounty.Dialogs
{
    [Serializable]
#if useSampleModel
    [LuisModel("162bf6ee-379b-4ce4-a519-5f5af90086b5", "11be6373fca44ded80fbe2afa8597c18")]
#else
    [LuisModel("90c7bbdb-85d5-4051-8d89-b95235a42f8e", "96adaa9ef3b44842b2685e60bcc39520")]
#endif
    public class BountyLuisDialog : LuisDialog<object>
    {public object Url { get; private set; }
        


        [LuisIntent("")]
        [LuisIntent("None")]
        public async Task None(IDialogContext context, LuisResult result)
        {
            string message = $"Sorry!! I didn't get you '{result.Query}'. Type 'help' if you need assistance.";

            await context.PostAsync(message);

            context.Wait(this.MessageReceived);
        }

        [LuisIntent("Help")]
        public async Task Help(IDialogContext context, LuisResult result)
        {
            int i;
            Random r = new Random();
            i = r.Next(1, 3);

            if (i == 1)
                await context.PostAsync($" Iam always there to help you :) Try asking me things like 'Suggest me gifts for my friend' 'Gift suggestions for House Warming' 'want to gift my sister.'");
            if (i == 2)
                        await context.PostAsync($"Dont worry Iam here to help you ! Try asking me things like 'Suggest me gifts for my cousin' 'Gift suggestions for Congratulating' 'want to gift my mother.'");
                       if (i == 3)
                        await context.PostAsync($"Hey iam here ! Try asking me things like 'Suggest me gifts for my father' 'Gift suggestions for Retirement' 'want to gift my brother'.");
        
                  context.Wait(this.MessageReceived);


        }
        [LuisIntent("Hello")]
        public async Task Hello(IDialogContext context, LuisResult result)
        {
            int i;
            Random r = new Random();

            i = r.Next(1, 3);

            if (i == 1)
                await context.PostAsync($" Hello ! Welcome to Bounty- Gift suggestor. Iam here to help you find a perfect gift for your loved ones.");
            if (i == 2)
                await context.PostAsync($"Hey ! Bounty-Gift suggestor welcomes you. Gift your loved ones and make them feel special.");
            if (i == 3)
                await context.PostAsync($"Hi ! Want to gift your loved ones. Confused ?? Try our Bounty- Gift suggestor.");

            context.Wait(this.MessageReceived);
        }

        [LuisIntent("Thankyou")]
        public async Task Thankyou(IDialogContext context, LuisResult result)
        {
            int i;
            Random r = new Random();

            i = r.Next(1, 3);

            if (i == 1)
                await context.PostAsync($" Your most welcome ! Come back soon. I will be waiting.");
            if (i == 2)
                await context.PostAsync($"Hope you liked the gift! I will be waiting. Come back soon.");
            if (i == 3)
                await context.PostAsync($"My pleasure ! Hope they love the gift. Come back.");
            context.Wait(this.MessageReceived);
        }


        [LuisIntent("ShowMeGifts")]
        public async Task ShowMeGifts(IDialogContext context, LuisResult result)

        {
            await context.PostAsync("It's good to know that you are going to gift someone.To whom you want to gift??(like mother,brother...)");

            context.Wait(this.MessageReceived);

        }
        
        [LuisIntent("Father")]
        public async Task Father(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new AskingForAge(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }
        [LuisIntent("Father1")]
        public async Task Father1(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new FatherDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }

        [LuisIntent("Mother")]
        public async Task Mother(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new AskingForAge(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }

        [LuisIntent("Mother1")]
        public async Task Mother1(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new MotherDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }
        [LuisIntent("BoyFriendDialog")]
        public async Task BoyFriendDialog(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new BoyFriendDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }
        [LuisIntent("GirlFriendDialog")]
        public async Task GirlFriendDialog(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new GirlFriendDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }
        [LuisIntent("HusbandDialog")]
        public async Task HusbandDialog(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new AskingForAge(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }

        [LuisIntent("HusbandDialog1")]
        public async Task HusbandDialog1(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new HusbandDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }
        [LuisIntent("WifeDialog")]
        public async Task WifeDialog(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new AskingForAge(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }

        [LuisIntent("WifeDialog1")]
        public async Task WifeDialog1(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new WifeDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }



      
        [LuisIntent("Brother")]
        public async Task Brother(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new AskingForAge(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }

        [LuisIntent("Brother1")]
        public async Task Brother1(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new BrotherDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }


        

        
        [LuisIntent("Sister")]
        public async Task Sister(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new AskingForAge(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }
        [LuisIntent("Sister1")]
        public async Task Sister1(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new SisterDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }

        [LuisIntent("FriendCousin")]
        public async Task FriendCousin(IDialogContext context, LuisResult result)
        {
            await context.PostAsync("Please let us know the gender of the person...");

            context.Wait(this.MessageReceived);
        }
      [LuisIntent("GrandFather")]
        public async Task GrandFather(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new GrandFatherDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);
        }
        [LuisIntent("GrandMother")]
        public async Task GrandMother(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new GrandMotherDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);
        }


        [LuisIntent("Male")]
    public async Task Male(IDialogContext context, LuisResult result)
    {
        var message = result;
        await context.Forward(new MaleDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
        context.Wait(this.MessageReceived);
    }

        [LuisIntent("Son")]
        public async Task Son(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new MaleDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);
        }

        [LuisIntent("Female")]
        public async Task Female(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new FemaleDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);
        }

        [LuisIntent("Daughter")]
        public async Task Daughter(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new FemaleDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);
        }
        [LuisIntent("Baby")]
        public async Task Baby(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new OneToTenDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);
        }

        [LuisIntent("OneToTen")]
        public async Task OneToTen(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new OneToTenDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }
        [LuisIntent("ElevenToForty")]
        public async Task ElevenToForty(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new ElevenToFortyDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);

        }

        [LuisIntent("FortyoneToSixty")]
        public async Task FortyoneToSixty(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new FortyoneToSixty(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);
        }
        [LuisIntent("Anniversary")]
        public async Task Anniversary(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new Anniversary(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);
        }
        [LuisIntent("Congratulations")]
        public async Task Congratulations(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new CongratulationsDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);
        }
        [LuisIntent("Retirement")]
        public async Task Retirement(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new RetirementDialog(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);
        }

        [LuisIntent("HouseWarming")]
        public async Task HouseWarming(IDialogContext context, LuisResult result)
        {
            var message = result;
            await context.Forward(new HouseWarming(), CallbackFirstDialog, message, System.Threading.CancellationToken.None);
            context.Wait(this.MessageReceived);
        }






        private async Task CallbackFirstDialog(IDialogContext context, IAwaitable<object> result)
        {
           // await context.PostAsync("");
            context.Wait(MessageReceived);

        }



    }
}
