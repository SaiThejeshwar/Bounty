﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Runtime.Remoting.Contexts;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.Bot.Builder.Luis;
using Microsoft.Bot.Builder.Luis.Models;
using HtmlAgilityPack;


namespace Bounty.Dialogs
{
    public class MotherDialog : IDialog<object>
    {
        int i;
        Random r = new Random();



        public async Task StartAsync(IDialogContext context)
        {

            var message3 = context.MakeMessage();
            message3.Attachments = new List<Attachment>();
            message3.AttachmentLayout = "carousel";
            HtmlWeb web2 = new HtmlWeb();
            HtmlDocument doc2 = web2.Load("https://www.gifts.com/mothers-day/IMX?tile=catpg_hero1&q=mothers+day&productgroup=glpmday/");
            var aTags = doc2.DocumentNode.SelectNodes("//img");

            if (aTags != null)
            {
                int count = 0;
                var a = "";
                foreach (var aTag in aTags)
                {

                    var msg = "";
                    var txt = "";
                    var href = "";

                    i = r.Next(1, 3);
                    if (i == 1)
                    {
                        a = "https://cimages.prvd.com/is/image/ProvideCommerce/GFB";
                    }
                    if (i == 2)
                        a = "https://cimages.prvd.com/is/image/ProvideCommerce/PCR";
                    if (i == 3)
                        a = "https://cimages.prvd.com/is/image/ProvideCommerce/RED";
                    if ((aTag.Attributes["src"].Value.StartsWith(a)) && count < 10)
                    {
                        //    msg = aTag.InnerHtml + " - " + aTag.Attributes["src"].Value + "\t" + "<br />";
                        msg = aTag.Attributes["src"].Value;
                        txt = aTag.Attributes["alt"].Value;
                        HtmlNode parentNode = aTag.ParentNode;
                        href = parentNode.Attributes["href"].Value;
                        List<CardImage> CardImages = new List<CardImage>();
                        CardImages.Add(new CardImage()
                        {
                            Url = msg.ToString()
                        });
                        var herocard3 = new HeroCard
                        {

                            Images = CardImages,
                            Title = txt,
                            Buttons = new List<CardAction> { new CardAction(ActionTypes.OpenUrl, "Click Here", value: href.ToString()) }
                        };

                        Attachment attachment1 = herocard3.ToAttachment();

                        message3.Attachments.Add(attachment1);
                        count = count + 1;
                    }
                }
                await context.PostAsync(message3);
                //context.Wait(this.MessageReceived);
                //context.Done(new Object());
            }

        }



    }
}